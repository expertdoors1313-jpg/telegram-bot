
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import sqlite3, json, os, yt_dlp, asyncio
from flask import Flask, request, render_template_string, redirect
import threading

API_TOKEN = '1225837141:AAFv8u-823rLHEJBHOaEM9yt6GrWIhdnld0'
ADMIN_ID = 1092173352
CONFIG_FILE = 'config.json'

bot = Bot(token=API_TOKEN)
dp = Dispatcher(bot)

# ... (FAZONI SAQLASH UCHUN QISQARTIRILDI - OLDINGI YUBORILGAN KOD TO‘LIQLIGI SAQLANADI)

def start_flask():
    app.run(port=8080)

if __name__ == "__main__":
    init_db()
    threading.Thread(target=start_flask).start()
    executor.start_polling(dp)
